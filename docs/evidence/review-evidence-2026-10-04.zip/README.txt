Observed real data captured 2026-10-04, not synthetic fixtures.
Extract verify.py and run: python verify.py --verify <archive.zip>
Verification requires no network or installed project dependencies.
The database is a consistent backup, not a copied live WAL file.
Constituents match the bundled official CSV; latest rebalance dates are not independently verified.
Benchmark checks validate Yahoo prices against the recorded XBOM proxy schedule, not official opens.
Hashes detect archive changes, not source authenticity. EPS probes cover two names only.
Historical signals predate corrected filters; pending outcomes are not measured hit rates.
